package com.groupone.domain;

import com.groupone.bytecodegeneration.MethodGenerator;
import com.groupone.domain.node.statement.Statement;
import com.groupone.domain.scope.FunctionSignature;
import com.groupone.domain.type.BultInType;
import com.groupone.domain.type.Type;


public class Constructor extends Function {
    public Constructor(FunctionSignature signature, Statement block) {
        super(signature, block);
    }

    @Override
    public Type getReturnType() {
        return BultInType.VOID;
    }

    @Override
    public void accept(MethodGenerator generator) {
        generator.generate(this);
    }
}

package com.groupone.domain.node;


public interface Node {
}

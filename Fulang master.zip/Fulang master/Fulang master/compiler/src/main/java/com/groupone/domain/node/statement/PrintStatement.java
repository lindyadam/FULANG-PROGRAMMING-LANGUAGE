package com.groupone.domain.node.statement;

import com.groupone.bytecodegeneration.statement.StatementGenerator;
import com.groupone.domain.node.expression.Expression;


public class PrintStatement implements Statement {

    private final Expression expression;

    public PrintStatement(Expression expression) {

        this.expression = expression;
    }

    public Expression getExpression() {
        return expression;
    }


    @Override
    public void accept(StatementGenerator generator) {
        generator.generate(this);
    }
}

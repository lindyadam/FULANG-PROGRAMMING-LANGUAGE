package com.groupone.domain.node.statement;

import com.groupone.bytecodegeneration.statement.StatementGenerator;
import com.groupone.domain.node.Node;


@FunctionalInterface
public interface Statement extends Node {
    void accept(StatementGenerator generator);
}

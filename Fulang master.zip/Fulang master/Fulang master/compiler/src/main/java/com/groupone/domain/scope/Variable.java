package com.groupone.domain.scope;

import com.groupone.domain.type.Type;


public interface Variable {
    Type getType();
    String getName();
}

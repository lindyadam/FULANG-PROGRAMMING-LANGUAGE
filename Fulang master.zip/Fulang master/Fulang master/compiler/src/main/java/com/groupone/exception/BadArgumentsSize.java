package com.groupone.exception;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangParser.ExpressionContext;
import com.groupone.domain.scope.FunctionSignature;

import java.util.List;


public class BadArgumentsSize extends RuntimeException {
    public BadArgumentsSize(FunctionSignature function, List<ExpressionContext> calledParameters) {
        super("Bad arguments amount");
    }
}

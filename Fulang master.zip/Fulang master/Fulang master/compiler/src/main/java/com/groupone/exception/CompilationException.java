package com.groupone.exception;


public class CompilationException extends RuntimeException {
}

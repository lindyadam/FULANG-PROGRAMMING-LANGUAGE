package com.groupone.exception;


public class NoVisitorReturnedValueException extends CompilationException {
    public NoVisitorReturnedValueException() {
    }
}

package com.groupone.parsing;

import com.groupone.antlr.FulangLexer;
import com.groupone.antlr.FulangParser;
import com.groupone.domain.CompilationUnit;
import com.groupone.parsing.visitor.CompilationUnitVisitor;

import org.antlr.v4.runtime.*;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;


public class Parser {
    public CompilationUnit getCompilationUnit(String fileAbsolutePath) throws IOException {
        CharStream charStream = new ANTLRFileStream(fileAbsolutePath); //fileAbolutePath - file containing first enk code file
        FulangLexer lexer = new FulangLexer(charStream);  //create lexer (pass ful file to it)
        CommonTokenStream tokenStream = new CommonTokenStream(lexer);
        FulangParser parser = new FulangParser(tokenStream);

        ANTLRErrorListener errorListener = new FulangTreeWalkErrorListener(); //FulangTreeWalkErrorListener - handles parse tree visiting error events
        parser.addErrorListener(errorListener);

        CompilationUnitVisitor compilationUnitVisitor = new CompilationUnitVisitor();
        return parser.compilationUnit().accept(compilationUnitVisitor);
    }
}

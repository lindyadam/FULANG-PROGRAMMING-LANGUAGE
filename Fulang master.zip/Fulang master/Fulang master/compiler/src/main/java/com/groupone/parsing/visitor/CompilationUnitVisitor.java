package com.groupone.parsing.visitor;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.ClassDeclarationContext;
import com.groupone.antlr.FulangParser.CompilationUnitContext;
import com.groupone.domain.ClassDeclaration;
import com.groupone.domain.CompilationUnit;

import org.antlr.v4.runtime.misc.NotNull;


public class CompilationUnitVisitor extends FulangBaseVisitor<CompilationUnit> {

    @Override
    public CompilationUnit visitCompilationUnit(@NotNull CompilationUnitContext ctx) {
        ClassVisitor classVisitor = new ClassVisitor();
        ClassDeclarationContext classDeclarationContext = ctx.classDeclaration();
        ClassDeclaration classDeclaration = classDeclarationContext.accept(classVisitor);
        return new CompilationUnit(classDeclaration);
    }
}

package com.groupone.parsing.visitor;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.domain.scope.Field;
import com.groupone.domain.scope.Scope;
import com.groupone.domain.type.ClassType;
import com.groupone.domain.type.Type;
import com.groupone.util.TypeResolver;

import org.antlr.v4.runtime.misc.NotNull;


public class FieldVisitor extends FulangBaseVisitor<Field> {

    private final Scope scope;

    public FieldVisitor(Scope scope) {
        this.scope = scope;
    }

    @Override
    public Field visitField(@NotNull FulangParser.FieldContext ctx) {
        Type owner = scope.getClassType();
        Type type = TypeResolver.getFromTypeContext(ctx.type());
        String name = ctx.name().getText();
        return new Field(name, owner, type);
    }
}

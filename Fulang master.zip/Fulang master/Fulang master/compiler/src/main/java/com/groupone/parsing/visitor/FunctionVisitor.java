package com.groupone.parsing.visitor;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.BlockContext;
import com.groupone.antlr.FulangParser.FunctionContext;
import com.groupone.domain.Constructor;
import com.groupone.domain.Function;
import com.groupone.domain.node.statement.Statement;
import com.groupone.domain.scope.FunctionSignature;
import com.groupone.domain.scope.LocalVariable;
import com.groupone.domain.scope.Scope;
import com.groupone.parsing.visitor.statement.StatementVisitor;

import org.antlr.v4.runtime.misc.NotNull;


public class FunctionVisitor extends FulangBaseVisitor<Function> {

    private final Scope scope;

    public FunctionVisitor(Scope scope) {
        this.scope = new Scope(scope);
    }

    @Override
    public Function visitFunction(@NotNull FunctionContext ctx) {
        FunctionSignature signature = ctx.functionDeclaration().accept(new FunctionSignatureVisitor(scope));
        scope.addLocalVariable(new LocalVariable("this",scope.getClassType()));
        addParametersAsLocalVariables(signature);
        Statement block = getBlock(ctx);
        if(signature.getName().equals(scope.getClassName())) {
            return new Constructor(signature,block);
        }
        return new Function(signature, block);
    }

    private void addParametersAsLocalVariables(FunctionSignature signature) {
        signature.getParameters().stream()
                .forEach(param -> scope.addLocalVariable(new LocalVariable(param.getName(), param.getType())));
    }

    private Statement getBlock(FunctionContext functionContext) {
        StatementVisitor statementVisitor = new StatementVisitor(scope);
        BlockContext block = functionContext.block();
        return block.accept(statementVisitor);
    }
}

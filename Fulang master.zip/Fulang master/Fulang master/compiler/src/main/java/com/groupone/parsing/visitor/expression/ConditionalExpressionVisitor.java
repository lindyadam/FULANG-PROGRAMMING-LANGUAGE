package com.groupone.parsing.visitor.expression;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.ConditionalExpressionContext;
import com.groupone.antlr.FulangParser.ExpressionContext;
import com.groupone.domain.CompareSign;
import com.groupone.domain.node.expression.ConditionalExpression;
import com.groupone.domain.node.expression.Expression;
import com.groupone.domain.node.expression.Value;
import com.groupone.domain.type.BultInType;

import org.antlr.v4.runtime.misc.NotNull;

public class ConditionalExpressionVisitor extends FulangBaseVisitor<ConditionalExpression> {
    private final ExpressionVisitor expressionVisitor;

    public ConditionalExpressionVisitor(ExpressionVisitor expressionVisitor) {
        this.expressionVisitor = expressionVisitor;
    }

    @Override
    public ConditionalExpression visitConditionalExpression(@NotNull ConditionalExpressionContext ctx) {
        ExpressionContext leftExpressionCtx = ctx.expression(0);
        ExpressionContext rightExpressionCtx = ctx.expression(1);
        Expression leftExpression = leftExpressionCtx.accept(expressionVisitor);
        Expression rightExpression = rightExpressionCtx != null ? rightExpressionCtx.accept(expressionVisitor) : new Value(BultInType.INT, "0");
        CompareSign cmpSign = ctx.cmp != null ? CompareSign.fromString(ctx.cmp.getText()) : CompareSign.NOT_EQUAL;
        return new ConditionalExpression(leftExpression, rightExpression, cmpSign);
    }
}
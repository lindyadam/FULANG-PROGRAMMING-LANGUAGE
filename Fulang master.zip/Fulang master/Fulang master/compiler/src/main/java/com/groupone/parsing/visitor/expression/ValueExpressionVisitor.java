package com.groupone.parsing.visitor.expression;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.ValueContext;
import com.groupone.domain.node.expression.Value;
import com.groupone.domain.type.Type;
import com.groupone.util.TypeResolver;

import org.antlr.v4.runtime.misc.NotNull;

public class ValueExpressionVisitor extends FulangBaseVisitor<Value> {

    @Override
    public Value visitValue(@NotNull ValueContext ctx) {
        String value = ctx.getText();
        Type type = TypeResolver.getFromValue(ctx);
        return new Value(type, value);
    }
}
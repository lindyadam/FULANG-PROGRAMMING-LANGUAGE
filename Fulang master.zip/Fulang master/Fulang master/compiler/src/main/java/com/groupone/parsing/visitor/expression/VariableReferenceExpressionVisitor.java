package com.groupone.parsing.visitor.expression;

import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.VarReferenceContext;
import com.groupone.domain.node.expression.FieldReference;
import com.groupone.domain.node.expression.LocalVariableReference;
import com.groupone.domain.node.expression.Reference;
import com.groupone.domain.scope.Field;
import com.groupone.domain.scope.LocalVariable;
import com.groupone.domain.scope.Scope;
import com.groupone.domain.scope.Variable;

import org.antlr.v4.runtime.misc.NotNull;

public class VariableReferenceExpressionVisitor extends FulangBaseVisitor<Reference> {
    private final Scope scope;

    public VariableReferenceExpressionVisitor(Scope scope) {
        this.scope = scope;
    }

    @Override
    public Reference visitVarReference(@NotNull VarReferenceContext ctx) {
        String varName = ctx.getText();
        if(scope.isFieldExists(varName)) {
            Field field = scope.getField(varName);
            return new FieldReference(field);
        }
        LocalVariable variable = scope.getLocalVariable(varName);
        return new LocalVariableReference(variable);
    }
}
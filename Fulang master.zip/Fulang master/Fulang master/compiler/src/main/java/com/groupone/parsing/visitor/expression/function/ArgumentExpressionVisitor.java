package com.groupone.parsing.visitor.expression.function;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.ArgumentContext;
import com.groupone.antlr.FulangParser.NamedArgumentContext;
import com.groupone.domain.node.expression.Argument;
import com.groupone.domain.node.expression.Expression;
import com.groupone.parsing.visitor.expression.ExpressionVisitor;

import org.antlr.v4.runtime.misc.NotNull;

import java.util.Optional;


public class ArgumentExpressionVisitor extends FulangBaseVisitor<Argument> {

    private final ExpressionVisitor expressionVisitor;

    public ArgumentExpressionVisitor(ExpressionVisitor expressionVisitor) {
        this.expressionVisitor = expressionVisitor;
    }

    @Override
    public Argument visitArgument(@NotNull ArgumentContext ctx) {
        Expression value = ctx.expression().accept(expressionVisitor);
        return new Argument(value, Optional.empty());
    }

    @Override
    public Argument visitNamedArgument(@NotNull NamedArgumentContext ctx) {
        Expression value = ctx.expression().accept(expressionVisitor);
        String name = ctx.name().getText();
        return new Argument(value, Optional.of(name));
    }

}

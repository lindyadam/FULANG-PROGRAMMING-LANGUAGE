package com.groupone.parsing.visitor.expression.function;

import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.ParameterContext;
import com.groupone.antlr.FulangParser.ParameterWithDefaultValueContext;
import com.groupone.domain.node.expression.Expression;
import com.groupone.domain.node.expression.Parameter;
import com.groupone.domain.type.Type;
import com.groupone.parsing.visitor.expression.ExpressionVisitor;
import com.groupone.util.TypeResolver;

import org.antlr.v4.runtime.misc.NotNull;

import java.util.Optional;


public class ParameterExpressionVisitor extends FulangBaseVisitor<Parameter> {

    private final ExpressionVisitor expressionVisitor;

    public ParameterExpressionVisitor(ExpressionVisitor expressionVisitor) {
        this.expressionVisitor = expressionVisitor;
    }

    @Override
    public Parameter visitParameter(@NotNull ParameterContext ctx) {
        String name = ctx.ID().getText();
        Type type = TypeResolver.getFromTypeContext(ctx.type());
        return new Parameter(name, type, Optional.empty());
    }

    @Override
    public Parameter visitParameterWithDefaultValue(@NotNull ParameterWithDefaultValueContext ctx) {
        String name = ctx.ID().getText();
        Type type = TypeResolver.getFromTypeContext(ctx.type());
        Expression defaultValue = ctx.defaultValue.accept(expressionVisitor);
        return new Parameter(name, type, Optional.of(defaultValue));
    }
}

package com.groupone.parsing.visitor.statement;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.ExpressionContext;
import com.groupone.antlr.FulangParser.IfStatementContext;
import com.groupone.domain.node.expression.Expression;
import com.groupone.domain.node.statement.IfStatement;
import com.groupone.domain.node.statement.Statement;
import com.groupone.parsing.visitor.expression.ExpressionVisitor;

import org.antlr.v4.runtime.misc.NotNull;

public class IfStatementVisitor extends FulangBaseVisitor<IfStatement> {
    private final StatementVisitor statementVisitor;
    private final ExpressionVisitor expressionVisitor;

    public IfStatementVisitor(StatementVisitor statementVisitor, ExpressionVisitor expressionVisitor) {
        this.statementVisitor = statementVisitor;
        this.expressionVisitor = expressionVisitor;
    }

    @Override
    public IfStatement visitIfStatement(@NotNull IfStatementContext ctx) {
        ExpressionContext conditionalExpressionContext = ctx.expression();
        Expression condition = conditionalExpressionContext.accept(expressionVisitor);
        Statement trueStatement = ctx.trueStatement.accept(statementVisitor);
        if (ctx.falseStatement != null) {
            Statement falseStatement = ctx.falseStatement.accept(statementVisitor);
            return new IfStatement(condition, trueStatement, falseStatement);
        }
        return new IfStatement(condition, trueStatement);
    }
}
package com.groupone.parsing.visitor.statement;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.ExpressionContext;
import com.groupone.antlr.FulangParser.PrintStatementContext;
import com.groupone.domain.node.expression.Expression;
import com.groupone.domain.node.statement.PrintStatement;
import com.groupone.parsing.visitor.expression.ExpressionVisitor;

import org.antlr.v4.runtime.misc.NotNull;

public class PrintStatementVisitor extends FulangBaseVisitor<PrintStatement> {
    private final ExpressionVisitor expressionVisitor;

    public PrintStatementVisitor(ExpressionVisitor expressionVisitor) {
        this.expressionVisitor = expressionVisitor;
    }

    @Override
    public PrintStatement visitPrintStatement(@NotNull PrintStatementContext ctx) {
        ExpressionContext expressionCtx = ctx.expression();
        Expression expression = expressionCtx.accept(expressionVisitor);
        return new PrintStatement(expression);
    }
}
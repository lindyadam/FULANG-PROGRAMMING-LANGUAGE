package com.groupone.parsing.visitor.statement;

import com.groupone.antlr.FulangParser;
import com.groupone.antlr.FulangBaseVisitor;
import com.groupone.antlr.FulangParser.ExpressionContext;
import com.groupone.antlr.FulangParser.VariableDeclarationContext;
import com.groupone.domain.node.expression.Expression;
import com.groupone.domain.node.statement.VariableDeclaration;
import com.groupone.domain.scope.LocalVariable;
import com.groupone.domain.scope.Scope;
import com.groupone.parsing.visitor.expression.ExpressionVisitor;

import org.antlr.v4.runtime.misc.NotNull;

public class VariableDeclarationStatementVisitor extends FulangBaseVisitor<VariableDeclaration> {
    private final ExpressionVisitor expressionVisitor;
    private final Scope scope;

    public VariableDeclarationStatementVisitor(ExpressionVisitor expressionVisitor, Scope scope) {
        this.expressionVisitor = expressionVisitor;
        this.scope = scope;
    }

    @Override
    public VariableDeclaration visitVariableDeclaration(@NotNull VariableDeclarationContext ctx) {
        String varName = ctx.name().getText();
        ExpressionContext expressionCtx = ctx.expression();
        Expression expression = expressionCtx.accept(expressionVisitor);
        scope.addLocalVariable(new LocalVariable(varName, expression.getType()));
        return new VariableDeclaration(varName, expression);
    }
}
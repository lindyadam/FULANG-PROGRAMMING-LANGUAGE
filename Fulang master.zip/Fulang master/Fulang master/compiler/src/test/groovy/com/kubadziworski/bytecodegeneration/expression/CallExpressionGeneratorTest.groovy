package com.kubadziworski.bytecodegeneration.expression

import spock.lang.Specification

/**
 * Created by kuba on 12.05.16.
 */
class CallExpressionGeneratorTest extends Specification {
}
